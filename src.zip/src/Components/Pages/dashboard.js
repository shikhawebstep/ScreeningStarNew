import React from 'react';

const Dashboard = () => {
  return (
    <div className='text-center'>
  
      <h1 className='text-5xl py-14'>Welcome To Screening Star</h1>
    </div>
  );
}

export default Dashboard;

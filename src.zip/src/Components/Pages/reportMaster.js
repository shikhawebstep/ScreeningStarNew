import React from 'react'

const ReportMaster = () => {
  return (
    <div>
      ReportMaster
    </div>
  )
}

export default ReportMaster

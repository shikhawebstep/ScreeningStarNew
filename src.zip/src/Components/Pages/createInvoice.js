import React from 'react'

const createInvoice = () => {
  return (
    <div>
      createInvoice
    </div>
  )
}

export default createInvoice

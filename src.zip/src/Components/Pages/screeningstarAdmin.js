import React from 'react'

const ScreeningstarAdmin = () => {
  return (
    <div>
      screeningstarAdmin
    </div>
  )
}

export default ScreeningstarAdmin

import React from 'react'

const CreateTickets = () => {
  return (
    <div>
       <h1 className='text-5xl text-center mt-52'>This Is User CreateTickets</h1>
    </div>
  )
}

export default CreateTickets

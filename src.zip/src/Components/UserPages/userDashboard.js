import React from 'react'

const userDashboard = () => {
  return (
    <div>
      <h1 className='text-5xl text-center mt-52'>This Is User Dashboard</h1>
    </div>
  )
}

export default userDashboard

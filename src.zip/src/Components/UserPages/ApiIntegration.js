import React from 'react'

const ApiIntegration = () => {
  return (
    <div>
       <h1 className='text-5xl text-center mt-52'>This Is User ApiIntegration</h1>
    </div>
  )
}

export default ApiIntegration
